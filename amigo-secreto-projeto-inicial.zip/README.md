# Amigo Secreto

Aplicação web responsiva para organizar participantes e preferências.

## Esta versão
- Cadastro local de participantes, contatos e preferências.
- Configuração básica do encontro.
- Exportação da lista em JSON.
- Layout adaptado a celular.

## Limitações
Esta é uma demonstração inicial. Os dados ficam somente no navegador em que foram cadastrados. Ainda não existe sincronização entre participantes, autenticação, sorteio privado nem envio automático por WhatsApp. Evite inserir informações sensíveis.

## Publicação na Vercel
1. Acesse https://vercel.com e entre com GitHub.
2. Em Add New > Project, importe `danilolima-sys/amigo-secreto`.
3. Framework Preset: Other. Build Command e Output Directory podem ficar vazios. Root Directory: `.`.
4. Clique em Deploy. A Vercel fornecerá um endereço público.

## Próxima etapa
Configurar Supabase com autenticação, tabelas com RLS e função de sorteio executada no servidor. Nunca coloque a chave `service_role` no JavaScript público nem exponha o mapeamento completo do sorteio ao grupo.